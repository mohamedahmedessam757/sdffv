import { useLocation, Link } from 'react-router-dom';
import { Home, Calculator, Bot, LineChart, User } from 'lucide-react';
import { cn } from '../utils/cn';
import { useStore } from '../store/useStore';

export function Navigation() {
  const location = useLocation();
  const user = useStore((state) => state.user);

  if (!user) return null;

  const links = [
    { to: '/', icon: Home, label: 'Home' },
    { to: '/calculator', icon: Calculator, label: 'Calculator' },
    { to: '/ai-coach', icon: Bot, label: 'AI Coach' },
    { to: '/profile', icon: User, label: 'Profile' }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background-light border-t border-gray-800">
      <div className="max-w-screen-xl mx-auto px-4">
        <div className="flex justify-around py-3">
          {links.map(({ to, icon: Icon, label }) => (
            <Link
              key={to}
              to={to}
              className={cn(
                'flex flex-col items-center space-y-1 p-2 rounded-lg transition-all',
                'hover:text-primary',
                location.pathname === to ? 'text-primary' : 'text-gray-400'
              )}
            >
              <Icon className="w-6 h-6" />
              <span className="text-xs">{label}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}