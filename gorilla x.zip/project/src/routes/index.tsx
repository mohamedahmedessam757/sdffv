import { Routes, Route, Navigate } from 'react-router-dom';
import { Welcome } from '../pages/Welcome';
import { Login } from '../pages/auth/Login';
import { Register } from '../pages/auth/Register';
import { Onboarding } from '../pages/onboarding/Onboarding';
import { Dashboard } from '../pages/Dashboard';
import { Calculator } from '../pages/Calculator';
import { AICoach } from '../pages/AICoach';
import { Profile } from '../pages/Profile';
import { useStore } from '../store/useStore';

export function AppRoutes() {
  const user = useStore((state) => state.user);

  if (!user) {
    return (
      <Routes>
        <Route path="/" element={<Welcome />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Dashboard />} />
      <Route path="/calculator" element={<Calculator />} />
      <Route path="/ai-coach" element={<AICoach />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}