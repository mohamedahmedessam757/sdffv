import { create } from 'zustand';
import type { User, MacroBreakdown } from '../types';

interface Store {
  user: User | null;
  macros: MacroBreakdown | null;
  setUser: (user: User) => void;
  setMacros: (macros: MacroBreakdown) => void;
  logout: () => void;
}

export const useStore = create<Store>((set) => ({
  user: null,
  macros: null,
  setUser: (user) => set({ user }),
  setMacros: (macros) => set({ macros }),
  logout: () => set({ user: null, macros: null }),
}));