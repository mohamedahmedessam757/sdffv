import { BrowserRouter as Router } from 'react-router-dom';
import { AppRoutes } from './routes';
import { Navigation } from './components/Navigation';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-background-dark text-white">
        <AppRoutes />
        <Navigation />
      </div>
    </Router>
  );
}

export default App;