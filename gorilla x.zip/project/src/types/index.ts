export interface User {
  id: string;
  name: string;
  email: string;
  goals: FitnessGoals;
  metrics: UserMetrics;
}

export interface UserMetrics {
  age: number;
  weight: number;
  height: number;
  gender: 'male' | 'female' | 'other';
  activityLevel: ActivityLevel;
}

export type ActivityLevel = 'sedentary' | 'light' | 'moderate' | 'active' | 'very-active';

export interface FitnessGoals {
  primary: 'weight-loss' | 'muscle-gain' | 'maintenance' | 'endurance';
  targetWeight?: number;
  weeklyGoal?: number;
}

export interface MacroBreakdown {
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
}