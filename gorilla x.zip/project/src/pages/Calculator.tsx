import { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator as CalcIcon } from 'lucide-react';
import { Input } from '../components/ui/Input';
import { Button } from '../components/ui/Button';
import { useStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';
import type { ActivityLevel } from '../types';

export function Calculator() {
  const navigate = useNavigate();
  const { user, setMacros } = useStore();
  const [formData, setFormData] = useState({
    age: user?.metrics.age.toString() || '',
    weight: user?.metrics.weight.toString() || '',
    height: user?.metrics.height.toString() || '',
    gender: user?.metrics.gender || 'male',
    activityLevel: user?.metrics.activityLevel || 'moderate' as ActivityLevel,
    goal: user?.goals.primary || 'maintenance'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic BMR calculation using Mifflin-St Jeor Equation
    const weight = parseFloat(formData.weight);
    const height = parseFloat(formData.height);
    const age = parseInt(formData.age);
    
    let bmr = 10 * weight + 6.25 * height - 5 * age;
    bmr = formData.gender === 'male' ? bmr + 5 : bmr - 161;

    // Activity multiplier
    const activityMultipliers = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      'very-active': 1.9
    };

    let tdee = bmr * activityMultipliers[formData.activityLevel];

    // Adjust for goal
    switch (formData.goal) {
      case 'weight-loss':
        tdee -= 500;
        break;
      case 'muscle-gain':
        tdee += 300;
        break;
      case 'endurance':
        tdee += 150;
        break;
    }

    // Calculate macros
    const macros = {
      calories: Math.round(tdee),
      protein: Math.round(weight * 2.2), // 2.2g per kg of body weight
      fats: Math.round((tdee * 0.25) / 9), // 25% of calories from fat
      carbs: Math.round((tdee - (weight * 2.2 * 4) - ((tdee * 0.25) / 9) * 9) / 4) // Remaining calories from carbs
    };

    setMacros(macros);
    navigate('/'); // Redirect to dashboard after calculation
  };

  return (
    <div className="min-h-screen pb-20 bg-background-dark">
      <div className="max-w-xl mx-auto px-4 py-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-background-light rounded-2xl p-6"
        >
          <div className="flex items-center gap-3 mb-6">
            <CalcIcon className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">Macro Calculator</h1>
              <p className="text-gray-400">Calculate your daily nutritional needs</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <Input
              label="Age"
              type="number"
              value={formData.age}
              onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
              required
            />

            <Input
              label="Weight (kg)"
              type="number"
              step="0.1"
              value={formData.weight}
              onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
              required
            />

            <Input
              label="Height (cm)"
              type="number"
              value={formData.height}
              onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
              required
            />

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-200">
                Gender
              </label>
              <div className="flex gap-4">
                {['male', 'female'].map((gender) => (
                  <label key={gender} className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="gender"
                      value={gender}
                      checked={formData.gender === gender}
                      onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value }))}
                      className="text-primary"
                    />
                    <span className="capitalize">{gender}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-200">
                Activity Level
              </label>
              <select
                value={formData.activityLevel}
                onChange={(e) => setFormData(prev => ({ ...prev, activityLevel: e.target.value as ActivityLevel }))}
                className="w-full rounded-lg bg-background-dark px-4 py-3 text-white border border-gray-700 focus:border-primary"
              >
                <option value="sedentary">Sedentary (office job)</option>
                <option value="light">Light Exercise (1-2 days/week)</option>
                <option value="moderate">Moderate Exercise (3-5 days/week)</option>
                <option value="active">Active (6-7 days/week)</option>
                <option value="very-active">Very Active (athlete)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-200">
                Goal
              </label>
              <select
                value={formData.goal}
                onChange={(e) => setFormData(prev => ({ ...prev, goal: e.target.value }))}
                className="w-full rounded-lg bg-background-dark px-4 py-3 text-white border border-gray-700 focus:border-primary"
              >
                <option value="weight-loss">Weight Loss</option>
                <option value="maintenance">Maintenance</option>
                <option value="muscle-gain">Muscle Gain</option>
                <option value="endurance">Improve Endurance</option>
              </select>
            </div>

            <Button type="submit" className="w-full" size="lg">
              Calculate Macros
            </Button>
          </form>
        </motion.div>
      </div>
    </div>
  );
}