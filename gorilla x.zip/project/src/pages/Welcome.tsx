import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Dumbbell } from 'lucide-react';
import Particles from '@tsparticles/react';
import { loadSlim } from '@tsparticles/slim';
import { Button } from '../components/ui/Button';

export function Welcome() {
  const navigate = useNavigate();

  const particlesInit = useCallback(async (engine: any) => {
    await loadSlim(engine);
  }, []);

  return (
    <div className="relative min-h-screen bg-background-dark overflow-hidden">
      <Particles
        init={particlesInit}
        options={{
          particles: {
            color: { value: '#FF6B00' },
            links: {
              color: '#FF6B00',
              distance: 150,
              enable: true,
              opacity: 0.5,
              width: 1,
            },
            move: {
              enable: true,
              speed: 2,
            },
            number: {
              value: 50,
            },
            opacity: {
              value: 0.5,
            },
            size: {
              value: 1,
            },
          },
        }}
      />
      
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/20">
            <Dumbbell className="w-12 h-12 text-primary" />
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-4xl font-bold mb-4"
        >
          GORilllaX
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="text-xl text-gray-300 mb-8 max-w-md"
        >
          Fuel your journey with precision. Calculate your daily calories and macros in seconds and take control of your transformation.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="space-y-4 w-full max-w-xs"
        >
          <Button
            onClick={() => navigate('/register')}
            className="w-full"
            size="lg"
          >
            Get Started
          </Button>
          <Button
            onClick={() => navigate('/login')}
            variant="ghost"
            className="w-full"
            size="lg"
          >
            Login
          </Button>
        </motion.div>
      </div>
    </div>
  );
}