import { motion } from 'framer-motion';
import { Activity, Plus } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { useStore } from '../store/useStore';

export function Dashboard() {
  const { user, macros } = useStore();

  // Initialize with zeros if no macros are set
  const defaultMacros = macros || {
    calories: 0,
    protein: 0,
    carbs: 0,
    fats: 0
  };

  // Calculate consumed values (starting at 0)
  const consumed = {
    calories: 0,
    protein: 0,
    carbs: 0,
    fats: 0
  };

  // Calculate percentages
  const caloriePercentage = Math.round((consumed.calories / defaultMacros.calories) * 100) || 0;

  return (
    <div className="min-h-screen pb-20 bg-background-dark">
      <div className="max-w-xl mx-auto px-4 py-6 space-y-6">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-background-light rounded-2xl p-6"
        >
          <h1 className="text-2xl font-bold mb-2">
            Welcome back, {user?.name}!
          </h1>
          <p className="text-gray-400">
            {defaultMacros.calories === 0 
              ? "Head to the Calculator to set your daily targets!"
              : "Track your progress and stay on course with your fitness goals."}
          </p>
        </motion.div>

        {/* Calorie Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-background-light rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold">Daily Progress</h2>
            <Activity className="text-primary w-6 h-6" />
          </div>
          
          <div className="relative h-4 bg-gray-700 rounded-full mb-4">
            <div 
              className="absolute left-0 top-0 h-full bg-primary rounded-full transition-all duration-300"
              style={{ width: `${caloriePercentage}%` }}
            />
          </div>

          <div className="flex justify-between text-sm">
            <span className="text-gray-400">{consumed.calories} / {defaultMacros.calories} kcal</span>
            <span className="text-primary">{caloriePercentage}% of daily goal</span>
          </div>
        </motion.div>

        {/* Macros Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-background-light rounded-2xl p-6"
        >
          <h2 className="text-xl font-semibold mb-4">Macros Breakdown</h2>
          
          <div className="space-y-4">
            {[
              { label: 'Protein', value: defaultMacros.protein, consumed: consumed.protein, unit: 'g', color: 'bg-blue-500' },
              { label: 'Carbs', value: defaultMacros.carbs, consumed: consumed.carbs, unit: 'g', color: 'bg-green-500' },
              { label: 'Fats', value: defaultMacros.fats, consumed: consumed.fats, unit: 'g', color: 'bg-yellow-500' }
            ].map((macro) => (
              <div key={macro.label}>
                <div className="flex justify-between text-sm mb-1">
                  <span>{macro.label}</span>
                  <span className="text-gray-400">
                    {macro.consumed} / {macro.value}{macro.unit}
                  </span>
                </div>
                <div className="h-2 bg-gray-700 rounded-full">
                  <div 
                    className={`h-full rounded-full ${macro.color} transition-all duration-300`}
                    style={{ width: `${(macro.consumed / macro.value) * 100 || 0}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Quick Add Meal */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="fixed bottom-20 right-4"
        >
          <Button
            className="rounded-full w-14 h-14 shadow-lg"
            onClick={() => {/* TODO: Implement meal adding */}}
          >
            <Plus className="w-6 h-6" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}