import { motion } from 'framer-motion';
import { LogOut, User as UserIcon, Settings, ChevronRight } from 'lucide-react';
import { Button } from '../components/ui/Button';
import { useStore } from '../store/useStore';
import { useNavigate } from 'react-router-dom';

export function Profile() {
  const { user, logout } = useStore();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen pb-20 bg-background-dark">
      <div className="max-w-xl mx-auto px-4 py-6 space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-background-light rounded-2xl p-6"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
              <UserIcon className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-bold">{user?.name}</h2>
              <p className="text-gray-400">{user?.email}</p>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-background-dark rounded-lg cursor-pointer hover:bg-opacity-80">
              <div className="flex items-center gap-3">
                <Settings className="w-5 h-5 text-primary" />
                <span>Settings</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </div>

            <Button
              variant="ghost"
              className="w-full justify-start text-red-500 hover:text-red-400 hover:bg-red-500/10"
              onClick={handleLogout}
            >
              <LogOut className="w-5 h-5 mr-3" />
              Logout
            </Button>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-background-light rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold mb-4">Your Metrics</h3>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Age', value: user?.metrics.age },
              { label: 'Weight', value: `${user?.metrics.weight} kg` },
              { label: 'Height', value: `${user?.metrics.height} cm` },
              { label: 'Activity', value: user?.metrics.activityLevel },
            ].map((metric) => (
              <div key={metric.label} className="bg-background-dark p-4 rounded-lg">
                <p className="text-gray-400 text-sm">{metric.label}</p>
                <p className="text-lg font-semibold">{metric.value}</p>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-background-light rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold mb-4">Fitness Goals</h3>
          <div className="space-y-4">
            <div className="bg-background-dark p-4 rounded-lg">
              <p className="text-gray-400 text-sm">Primary Goal</p>
              <p className="text-lg font-semibold capitalize">{user?.goals.primary.replace('-', ' ')}</p>
            </div>
            {user?.goals.targetWeight && (
              <div className="bg-background-dark p-4 rounded-lg">
                <p className="text-gray-400 text-sm">Target Weight</p>
                <p className="text-lg font-semibold">{user.goals.targetWeight} kg</p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}