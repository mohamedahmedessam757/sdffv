import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { useStore } from '../../store/useStore';
import type { ActivityLevel, FitnessGoals } from '../../types';

const steps = [
  {
    title: 'Basic Information',
    description: 'Let\'s get to know you better',
    fields: ['age', 'weight', 'height']
  },
  {
    title: 'Physical Details',
    description: 'Help us understand your current status',
    fields: ['gender', 'activityLevel']
  },
  {
    title: 'Your Goals',
    description: 'What do you want to achieve?',
    fields: ['goal', 'targetWeight']
  }
];

export function Onboarding() {
  const navigate = useNavigate();
  const { user, setUser } = useStore();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    age: '',
    weight: '',
    height: '',
    gender: 'male',
    activityLevel: 'moderate' as ActivityLevel,
    goal: 'weight-loss' as FitnessGoals['primary'],
    targetWeight: ''
  });

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      // Update user data and navigate to dashboard
      setUser({
        ...user!,
        metrics: {
          age: parseInt(formData.age),
          weight: parseFloat(formData.weight),
          height: parseInt(formData.height),
          gender: formData.gender as 'male' | 'female',
          activityLevel: formData.activityLevel,
        },
        goals: {
          primary: formData.goal,
          targetWeight: parseFloat(formData.targetWeight),
        },
      });
      navigate('/');
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-background-dark">
      <div className="w-full max-w-md">
        {/* Progress bar */}
        <div className="mb-8">
          <div className="h-2 bg-gray-700 rounded-full">
            <div
              className="h-full bg-primary rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="bg-background-light rounded-2xl p-8 space-y-6"
          >
            <div className="text-center">
              <h2 className="text-2xl font-bold">{steps[currentStep].title}</h2>
              <p className="text-gray-400 mt-2">{steps[currentStep].description}</p>
            </div>

            <div className="space-y-6">
              {currentStep === 0 && (
                <>
                  <Input
                    label="Age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                    required
                  />
                  <Input
                    label="Weight (kg)"
                    type="number"
                    step="0.1"
                    value={formData.weight}
                    onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
                    required
                  />
                  <Input
                    label="Height (cm)"
                    type="number"
                    value={formData.height}
                    onChange={(e) => setFormData(prev => ({ ...prev, height: e.target.value }))}
                    required
                  />
                </>
              )}

              {currentStep === 1 && (
                <>
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-200">
                      Gender
                    </label>
                    <div className="flex gap-4">
                      {['male', 'female'].map((gender) => (
                        <label key={gender} className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="gender"
                            value={gender}
                            checked={formData.gender === gender}
                            onChange={(e) => setFormData(prev => ({ ...prev, gender: e.target.value }))}
                            className="text-primary"
                          />
                          <span className="capitalize">{gender}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-200">
                      Activity Level
                    </label>
                    <select
                      value={formData.activityLevel}
                      onChange={(e) => setFormData(prev => ({ ...prev, activityLevel: e.target.value as ActivityLevel }))}
                      className="w-full rounded-lg bg-background-dark px-4 py-3 text-white border border-gray-700 focus:border-primary"
                    >
                      <option value="sedentary">Sedentary (office job)</option>
                      <option value="light">Light Exercise (1-2 days/week)</option>
                      <option value="moderate">Moderate Exercise (3-5 days/week)</option>
                      <option value="active">Active (6-7 days/week)</option>
                      <option value="very-active">Very Active (athlete)</option>
                    </select>
                  </div>
                </>
              )}

              {currentStep === 2 && (
                <>
                  <div className="space-y-2">
                    <label className="block text-sm font-medium text-gray-200">
                      Primary Goal
                    </label>
                    <select
                      value={formData.goal}
                      onChange={(e) => setFormData(prev => ({ ...prev, goal: e.target.value as FitnessGoals['primary'] }))}
                      className="w-full rounded-lg bg-background-dark px-4 py-3 text-white border border-gray-700 focus:border-primary"
                    >
                      <option value="weight-loss">Weight Loss</option>
                      <option value="muscle-gain">Build Muscle</option>
                      <option value="maintenance">Maintain Weight</option>
                      <option value="endurance">Improve Endurance</option>
                    </select>
                  </div>

                  <Input
                    label="Target Weight (kg)"
                    type="number"
                    step="0.1"
                    value={formData.targetWeight}
                    onChange={(e) => setFormData(prev => ({ ...prev, targetWeight: e.target.value }))}
                    required
                  />
                </>
              )}
            </div>

            <div className="flex justify-between pt-4">
              <Button
                variant="ghost"
                onClick={handleBack}
                className={currentStep === 0 ? 'invisible' : ''}
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <Button onClick={handleNext}>
                {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}