import { useState } from 'react';
import { motion } from 'framer-motion';
import { Bot, Send } from 'lucide-react';
import { Button } from '../components/ui/Button';

export function AICoach() {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Array<{ text: string; isUser: boolean }>>([
    { text: "Hello! I'm your AI fitness coach. How can I help you today?", isUser: false }
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    // Add user message
    setMessages(prev => [...prev, { text: message, isUser: true }]);
    
    // TODO: Implement actual AI chat functionality
    // For now, just add a mock response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        text: "I'm still in training! But I'll be able to help you with personalized workout and nutrition advice soon.",
        isUser: false
      }]);
    }, 1000);

    setMessage('');
  };

  return (
    <div className="min-h-screen pb-20 bg-background-dark flex flex-col">
      <div className="flex-1 max-w-xl mx-auto px-4 py-6 w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-background-light rounded-2xl p-6 mb-6"
        >
          <div className="flex items-center gap-3">
            <Bot className="w-8 h-8 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">AI Coach</h1>
              <p className="text-gray-400">Your personal fitness assistant</p>
            </div>
          </div>
        </motion.div>

        <div className="space-y-4 mb-6">
          {messages.map((msg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl p-4 ${
                  msg.isUser
                    ? 'bg-primary text-white'
                    : 'bg-background-light'
                }`}
              >
                {msg.text}
              </div>
            </motion.div>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="fixed bottom-20 left-0 right-0 px-4">
          <div className="max-w-xl mx-auto flex gap-2">
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Ask your AI coach anything..."
              className="flex-1 rounded-lg bg-background-light px-4 py-3 text-white border border-gray-700 focus:border-primary focus:outline-none"
            />
            <Button type="submit" className="px-4">
              <Send className="w-5 h-5" />
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}